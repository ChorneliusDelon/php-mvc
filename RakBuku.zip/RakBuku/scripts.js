// Book form, title, author, year, and status
const bookForm = document.getElementById('bookForm');
const titleInput = document.getElementById('titleInput');
const authorInput = document.getElementById('authorInput');
const yearInput = document.getElementById('yearInput');
const completeCheckbox = document.getElementById('completeCheckbox');

// Incomplete and complete bookshelf lists
const incompleteBookshelfList = document.getElementById('incompleteBookshelfList');
const completeBookshelfList = document.getElementById('completeBookshelfList');

// Add a book to a bookshelf list
function addBookToList(list, book) {
    const bookItem = document.createElement('article');
    bookItem.classList.add('book_item');
    bookItem.innerHTML = `
        <h3>${book.title}</h3>
        <p>Penulis: ${book.author}</p>
        <p>Tahun: ${book.year}</p>
        <div class="action">
            <button class="green">Selesai dibaca</button>
            <button class="red">Hapus buku</button>
        </div>
    `;

    const buttons = bookItem.querySelectorAll('button');
    buttons[0].addEventListener('click', () => updateBookStatus(book, list, bookItem));
    buttons[1].addEventListener('click', () => deleteBook(book, list, bookItem));

    list.appendChild(bookItem);
}

// Delete a book from a bookshelf list
function deleteBook(book, list, bookItem) {
    list.removeChild(bookItem);
}

// Update the status of a book and move it to the other list
function updateBookStatus(book, list, bookItem) {
    list.removeChild(bookItem);
    addBookToList(book.status === 'incomplete' ? incompleteBookshelfList : completeBookshelfList, book);
}

// Add a book when the form is submitted
bookForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const book = {
        title: titleInput.value,
        author: authorInput.value,
        year: yearInput.value,
        status: completeCheckbox.checked ? 'complete' : 'incomplete',
    };

    addBookToList(book.status === 'incomplete' ? incompleteBookshelfList : completeBookshelfList, book);

    bookForm.reset();
});